
package com.wifivoice.sender

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

class VoiceSenderService : Service() {

    companion object {
        private const val TAG = "VoiceSender"
        private const val CHANNEL_ID = "voice_sender_channel"
        private const val SERVICE_TYPE = "_wifivoice._tcp."
        private const val SAMPLE_RATE = 16000
        private const val NOTIFICATION_ID = 1
    }

    private var serverSocket: ServerSocket? = null
    private var nsdManager: NsdManager? = null

    private var registrationListener:
            NsdManager.RegistrationListener? = null

    @Volatile
    private var running = false

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()
        startNotification()

        running = true
        startServer()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            val channel = NotificationChannel(
                CHANNEL_ID,
                "WiFi Voice Sender",
                NotificationManager.IMPORTANCE_LOW
            )

            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun startNotification() {

        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

        val notification = builder
            .setContentTitle("WiFi Voice Sender")
            .setContentText("Waiting for receiver connection")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun getDeviceName(): String {

        val manufacturer = Build.MANUFACTURER
        val model = Build.MODEL

        return if (model.startsWith(manufacturer, true)) {
            model
        } else {
            "$manufacturer $model"
        }
    }

    // START SERVER

    private fun startServer() {

        thread(name = "VoiceServer") {

            try {

                serverSocket = ServerSocket(0)

                val port = serverSocket!!.localPort

                Log.d(TAG, "Server started: $port")

                registerDevice(port)

                // Only one receiver at a time

                while (running) {

                    val client = serverSocket!!.accept()

                    Log.d(TAG, "Receiver connected")

                    sendVoice(client)
                }

            } catch (e: Exception) {

                if (running) {
                    Log.e(TAG, "Server error", e)
                }
            }
        }
    }

    // WIFI DISCOVERY

    private fun registerDevice(port: Int) {

        nsdManager =
            getSystemService(Context.NSD_SERVICE) as NsdManager

        val deviceInfo = NsdServiceInfo().apply {

            serviceName = getDeviceName()
            serviceType = SERVICE_TYPE
            setPort(port)
        }

        registrationListener =
            object : NsdManager.RegistrationListener {

                override fun onServiceRegistered(
                    info: NsdServiceInfo
                ) {
                    Log.d(TAG, "Registered: ${info.serviceName}")
                }

                override fun onRegistrationFailed(
                    info: NsdServiceInfo,
                    errorCode: Int
                ) {
                    Log.e(TAG, "Registration failed: $errorCode")
                }

                override fun onServiceUnregistered(
                    info: NsdServiceInfo
                ) {
                    Log.d(TAG, "Unregistered")
                }

                override fun onUnregistrationFailed(
                    info: NsdServiceInfo,
                    errorCode: Int
                ) {
                    Log.e(TAG, "Unregistration failed: $errorCode")
                }
            }

        nsdManager?.registerService(
            deviceInfo,
            NsdManager.PROTOCOL_DNS_SD,
            registrationListener!!
        )
    }

    // SEND VOICE

    private fun sendVoice(socket: Socket) {

        // Check microphone permission

        if (checkSelfPermission(
                android.Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            Log.e(TAG, "Microphone permission not granted")

            try {
                socket.close()
            } catch (_: Exception) {}

            return
        }

        var audioRecord: AudioRecord? = null

        try {

            socket.tcpNoDelay = true

            val output = socket.getOutputStream()

            // Send device name

            val name = getDeviceName()
                .replace("\n", " ")
                .replace("\r", " ")

            output.write(
                (name + "\n").toByteArray(Charsets.UTF_8)
            )

            output.flush()

            val minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            if (minBuffer <= 0) {
                throw IllegalStateException("Invalid audio buffer")
            }

            // Check permission again before microphone access

            if (checkSelfPermission(
                    android.Manifest.permission.RECORD_AUDIO
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                throw SecurityException("Microphone permission denied")
            }

            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuffer * 2
            )

            if (audioRecord.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("AudioRecord initialization failed")
            }

            audioRecord.startRecording()

            val buffer = ByteArray(minBuffer)

            // Stream audio continuously

            while (
                running &&
                socket.isConnected &&
                !socket.isClosed
            ) {

                val count = audioRecord.read(
                    buffer,
                    0,
                    buffer.size
                )

                if (count > 0) {
                    output.write(buffer, 0, count)
                } else if (count < 0) {
                    throw IllegalStateException("Audio read error: $count")
                }
            }

        } catch (e: SecurityException) {

            Log.e(TAG, "Microphone security error", e)

        } catch (e: Exception) {

            Log.e(TAG, "Voice streaming error", e)

        } finally {

            try {
                audioRecord?.stop()
            } catch (_: Exception) {}

            audioRecord?.release()

            try {
                socket.close()
            } catch (_: Exception) {}

            Log.d(TAG, "Receiver disconnected")
        }
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        return START_STICKY
    }

    override fun onDestroy() {

        running = false

        try {
            registrationListener?.let {
                nsdManager?.unregisterService(it)
            }
        } catch (_: Exception) {}

        try {
            serverSocket?.close()
        } catch (_: Exception) {}

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
