
package com.wifivoice.receiver

import android.content.Context
import android.util.Log
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AudioRecorder(context: Context) {

    companion object {
        private const val TAG = "AudioRecorder"
        private const val SAMPLE_RATE = 16000
        private const val CHANNELS = 1
        private const val BITS_PER_SAMPLE = 16
    }

    private val appContext = context.applicationContext

    private var file: RandomAccessFile? = null
    private var recordingFile: File? = null
    private var totalAudioBytes = 0L

    @Synchronized
    fun startRecording(): File {

        stopRecording()

        val folder = File(
            appContext.getExternalFilesDir(null),
            "VoiceRecordings"
        )

        if (!folder.exists()) {
            folder.mkdirs()
        }

        val time = SimpleDateFormat(
            "yyyyMMdd_HHmmss",
            Locale.getDefault()
        ).format(Date())

        val outputFile = File(
            folder,
            "Voice_$time.wav"
        )

        file = RandomAccessFile(outputFile, "rw")
        file?.setLength(0)

        totalAudioBytes = 0L
        recordingFile = outputFile

        // Reserve WAV header
        file?.write(ByteArray(44))

        Log.d(TAG, "Recording started: ${outputFile.absolutePath}")

        return outputFile
    }

    @Synchronized
    fun writeAudio(data: ByteArray, length: Int) {

        val output = file ?: return

        if (length <= 0 || length > data.size) return

        output.write(data, 0, length)

        totalAudioBytes += length
    }

    @Synchronized
    fun stopRecording(): File? {

        val output = file ?: return recordingFile

        try {

            // Write WAV header

            output.seek(0)

            val byteRate =
                SAMPLE_RATE * CHANNELS * BITS_PER_SAMPLE / 8

            val blockAlign =
                CHANNELS * BITS_PER_SAMPLE / 8

            output.writeBytes("RIFF")
            writeInt(output, (totalAudioBytes + 36).toInt())

            output.writeBytes("WAVE")
            output.writeBytes("fmt ")
            writeInt(output, 16)
            writeShort(output, 1)
            writeShort(output, CHANNELS)
            writeInt(output, SAMPLE_RATE)
            writeInt(output, byteRate)
            writeShort(output, blockAlign)
            writeShort(output, BITS_PER_SAMPLE)

            output.writeBytes("data")
            writeInt(output, totalAudioBytes.toInt())

            output.close()

            Log.d(
                TAG,
                "Recording saved: ${recordingFile?.absolutePath}"
            )

        } catch (e: Exception) {

            Log.e(TAG, "Recording save error", e)

        } finally {

            file = null
        }

        return recordingFile
    }

    private fun writeInt(
        output: RandomAccessFile,
        value: Int
    ) {
        output.write(value and 0xff)
        output.write((value shr 8) and 0xff)
        output.write((value shr 16) and 0xff)
        output.write((value shr 24) and 0xff)
    }

    private fun writeShort(
        output: RandomAccessFile,
        value: Int
    ) {
        output.write(value and 0xff)
        output.write((value shr 8) and 0xff)
    }
}
