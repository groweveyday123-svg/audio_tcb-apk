
package com.wifivoice.receiver

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log
import java.net.InetAddress

data class SenderDevice(
    val name: String,
    val ipAddress: String,
    val port: Int
)

class WifiDiscovery(
    context: Context,
    private val onDevicesChanged: (List<SenderDevice>) -> Unit
) {

    companion object {
        private const val TAG = "WifiDiscovery"
        private const val SERVICE_TYPE = "_wifivoice._tcp."
    }

    private val nsdManager =
        context.applicationContext.getSystemService(
            Context.NSD_SERVICE
        ) as NsdManager

    private val devices = mutableMapOf<String, SenderDevice>()

    private var discoveryListener:
            NsdManager.DiscoveryListener? = null

    fun startDiscovery() {

        if (discoveryListener != null) return

        val listener = object : NsdManager.DiscoveryListener {

            override fun onDiscoveryStarted(serviceType: String) {
                Log.d(TAG, "Discovery started")
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {

                Log.d(TAG, "Found: ${serviceInfo.serviceName}")

                if (serviceInfo.serviceType.trimEnd('.') !=
                    SERVICE_TYPE.trimEnd('.')
                ) {
                    return
                }

                nsdManager.resolveService(
                    serviceInfo,
                    object : NsdManager.ResolveListener {

                        override fun onResolveFailed(
                            info: NsdServiceInfo,
                            errorCode: Int
                        ) {
                            Log.e(TAG, "Resolve failed: $errorCode")
                        }

                        override fun onServiceResolved(
                            info: NsdServiceInfo
                        ) {

                            val address: InetAddress =
                                info.host ?: return

                            val device = SenderDevice(
                                name = info.serviceName,
                                ipAddress = address.hostAddress ?: return,
                                port = info.port
                            )

                            synchronized(devices) {
                                devices[info.serviceName] = device
                                notifyDevices()
                            }

                            Log.d(
                                TAG,
                                "Device connected to network: ${device.name}"
                            )
                        }
                    }
                )
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {

                synchronized(devices) {
                    devices.remove(serviceInfo.serviceName)
                    notifyDevices()
                }

                Log.d(TAG, "Device lost: ${serviceInfo.serviceName}")
            }

            override fun onDiscoveryStopped(serviceType: String) {
                Log.d(TAG, "Discovery stopped")
            }

            override fun onStartDiscoveryFailed(
                serviceType: String,
                errorCode: Int
            ) {
                Log.e(TAG, "Discovery start failed: $errorCode")

                try {
                    nsdManager.stopServiceDiscovery(this)
                } catch (_: Exception) {
                }

                discoveryListener = null
            }

            override fun onStopDiscoveryFailed(
                serviceType: String,
                errorCode: Int
            ) {
                Log.e(TAG, "Discovery stop failed: $errorCode")
            }
        }

        discoveryListener = listener

        try {
            nsdManager.discoverServices(
                SERVICE_TYPE,
                NsdManager.PROTOCOL_DNS_SD,
                listener
            )
        } catch (e: Exception) {
            discoveryListener = null
            Log.e(TAG, "Discovery error", e)
        }
    }

    private fun notifyDevices() {
        onDevicesChanged(devices.values.toList())
    }

    fun stopDiscovery() {

        val listener = discoveryListener ?: return

        try {
            nsdManager.stopServiceDiscovery(listener)
        } catch (e: Exception) {
            Log.e(TAG, "Stop discovery error", e)
        }

        discoveryListener = null

        synchronized(devices) {
            devices.clear()
            notifyDevices()
        }
    }
}
