
package com.wifivoice.receiver

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import android.os.Handler
import android.os.Looper
import java.net.Socket
import kotlin.concurrent.thread

class VoiceReceiver(
    private val recorder: AudioRecorder,
    private val onStatusChanged: (String) -> Unit
) {

    companion object {
        private const val TAG = "VoiceReceiver"
        private const val SAMPLE_RATE = 16000
    }

    @Volatile
    private var running = false

    private var socket: Socket? = null
    private var audioTrack: AudioTrack? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    private fun updateStatus(status: String) {
        mainHandler.post {
            onStatusChanged(status)
        }
    }

    fun connect(device: SenderDevice) {

        if (running) return

        running = true

        thread(name = "VoiceReceiverThread") {

            try {

                updateStatus("Connecting to ${device.name}")

                val connection = Socket(
                    device.ipAddress,
                    device.port
                )

                socket = connection
                connection.tcpNoDelay = true

                val input = connection.getInputStream()

                // Read sender name

                val nameBytes = ArrayList<Byte>()

                while (running) {

                    val value = input.read()

                    if (value == -1) {
                        throw Exception("Sender disconnected")
                    }

                    if (value == 10) break

                    if (nameBytes.size >= 256) {
                        throw Exception("Invalid device name")
                    }

                    nameBytes.add(value.toByte())
                }

                val senderName = String(
                    nameBytes.toByteArray(),
                    Charsets.UTF_8
                )

                updateStatus("Connected: $senderName")

                // Start recording

                val savedFile = recorder.startRecording()

                Log.d(TAG, "Recording: ${savedFile.absolutePath}")

                val minBuffer = AudioTrack.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )

                if (minBuffer <= 0) {
                    throw Exception("Invalid audio buffer")
                }

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(
                                AudioAttributes.CONTENT_TYPE_SPEECH
                            )
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(
                                AudioFormat.CHANNEL_OUT_MONO
                            )
                            .setEncoding(
                                AudioFormat.ENCODING_PCM_16BIT
                            )
                            .build()
                    )
                    .setBufferSizeInBytes(minBuffer * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                audioTrack = track

                track.play()

                updateStatus("Playing and recording: $senderName")

                val buffer = ByteArray(minBuffer)

                while (running && !connection.isClosed) {

                    val count = input.read(
                        buffer,
                        0,
                        buffer.size
                    )

                    if (count == -1) break

                    if (count > 0) {

                        // Save received audio

                        recorder.writeAudio(buffer, count)

                        // Play received audio

                        var offset = 0

                        while (running && offset < count) {

                            val written = track.write(
                                buffer,
                                offset,
                                count - offset,
                                AudioTrack.WRITE_BLOCKING
                            )

                            if (written < 0) {
                                throw Exception("Audio playback error")
                            }

                            offset += written
                        }
                    }
                }

                updateStatus("Sender disconnected")

            } catch (e: Exception) {

                Log.e(TAG, "Receiver error", e)

                updateStatus("Connection error: ${e.message}")

            } finally {

                running = false

                try {
                    audioTrack?.pause()
                    audioTrack?.flush()
                    audioTrack?.stop()
                    audioTrack?.release()
                } catch (_: Exception) {}

                audioTrack = null

                try {
                    socket?.close()
                } catch (_: Exception) {}

                socket = null

                val savedFile = recorder.stopRecording()

                if (savedFile != null) {
                    updateStatus("Recording saved: ${savedFile.name}")
                }
            }
        }
    }

    fun disconnect() {

        running = false

        try {
            socket?.close()
        } catch (_: Exception) {}

        try {
            audioTrack?.pause()
            audioTrack?.release()
        } catch (_: Exception) {}

        socket = null
        audioTrack = null

        updateStatus("Disconnected")
    }
}
