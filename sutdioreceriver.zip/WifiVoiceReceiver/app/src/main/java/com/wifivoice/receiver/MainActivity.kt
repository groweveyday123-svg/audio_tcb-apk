
package com.wifivoice.receiver

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    private lateinit var discovery: WifiDiscovery
    private lateinit var recorder: AudioRecorder

    private var receiver: VoiceReceiver? = null

    private val devices = mutableStateListOf<SenderDevice>()

    private var status by mutableStateOf("Searching for Sender devices...")

    private var connectedDevice by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        recorder = AudioRecorder(this)

        discovery = WifiDiscovery(this) { foundDevices ->

            runOnUiThread {
                devices.clear()
                devices.addAll(foundDevices)
            }
        }

        setContent {

            MaterialTheme {

                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp)
                    ) {

                        Text(
                            text = "WiFi Voice Receiver",
                            style = MaterialTheme.typography.headlineMedium
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = status,
                            style = MaterialTheme.typography.bodyLarge
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Available Sender Devices",
                            style = MaterialTheme.typography.titleMedium
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        if (devices.isEmpty()) {

                            Text(
                                text = "No Sender devices found. Check WiFi connection.",
                                style = MaterialTheme.typography.bodyMedium
                            )

                        } else {

                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {

                                items(
                                    items = devices,
                                    key = { it.name }
                                ) { device ->

                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {

                                                connectToDevice(device)
                                            }
                                    ) {

                                        Column(
                                            modifier = Modifier.padding(16.dp)
                                        ) {

                                            Text(
                                                text = device.name,
                                                style = MaterialTheme.typography.titleMedium
                                            )

                                            Spacer(
                                                modifier = Modifier.height(4.dp)
                                            )

                                            Text(
                                                text = "${device.ipAddress}:${device.port}",
                                                style = MaterialTheme.typography.bodySmall
                                            )

                                            Spacer(
                                                modifier = Modifier.height(4.dp)
                                            )

                                            Text(
                                                text = if (
                                                    connectedDevice == device.name
                                                ) {
                                                    "Connected"
                                                } else {
                                                    "Tap to receive voice"
                                                },
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (connectedDevice.isNotEmpty()) {

                            Text(
                                text = "Receiving from: $connectedDevice"
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Button(
                                onClick = {
                                    receiver?.disconnect()
                                    receiver = null
                                    connectedDevice = ""
                                    status = "Disconnected"
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Disconnect")
                            }
                        }
                    }
                }
            }
        }
    }

    private fun connectToDevice(device: SenderDevice) {

        if (receiver != null) {
            receiver?.disconnect()
            receiver = null
            connectedDevice = ""
        }

        status = "Connecting to ${device.name}..."

        val newReceiver = VoiceReceiver(recorder) { newStatus ->

            status = newStatus

            if (newStatus.startsWith("Recording saved:")) {
                connectedDevice = ""
                receiver = null
            }

            if (newStatus.startsWith("Connection error:")) {
                connectedDevice = ""
                receiver = null
            }
        }

        receiver = newReceiver
        connectedDevice = device.name

        newReceiver.connect(device)
    }

    override fun onStart() {
        super.onStart()

        if (::discovery.isInitialized) {
            discovery.startDiscovery()
        }
    }

    override fun onStop() {
        if (::discovery.isInitialized) {
            discovery.stopDiscovery()
        }

        super.onStop()
    }

    override fun onDestroy() {

        receiver?.disconnect()
        receiver = null

        super.onDestroy()
    }
}
